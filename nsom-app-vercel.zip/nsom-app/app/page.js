import NsomApp from "../components/NsomApp";

export default function Home() {
  return <NsomApp />;
}
